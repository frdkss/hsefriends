# hsefriends
tg bot for finding your soulmates among HSE students \n ૮ ˶ᵔ ᵕ ᵔ˶ ა
