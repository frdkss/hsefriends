import os

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import CallbackQuery, Message, ReplyKeyboardRemove
from aiogram.fsm.context import FSMContext
from pyexpat.errors import messages
from sqlalchemy import select

from callbacks.usr_callbacks import callback_menu
from database.db_cfg import accounts_db_session
from keyboards.default_keyboards import user_sex, user_course_bac, no_about, user_friend_sex, no_photo, user_isBaccalaureate
from keyboards.inline_keyboards import back_to_main
from database.models import AccountsTable
from .forms.state_forms import RewriteProfile

router = Router()


@router.callback_query(F.data == 'rewrite_profile')
async def state_user_rewrite(event: Message | CallbackQuery, state: FSMContext):
    """Запуск редактирования профиля."""
    chat_id = event.message.chat.id if isinstance(event, CallbackQuery) else event.chat.id

    # Получение текущего профиля пользователя из базы данных
    async with accounts_db_session() as session:
        query = select(AccountsTable).where(AccountsTable.chat_id == chat_id)
        result = await session.execute(query)
        user_profile = result.scalar_one_or_none()

    if not user_profile:
        await event.message.answer("Профиль не найден.")
        return

    # Сохранение текущего состояния для редактирования
    await state.update_data(profile=user_profile)
    await state.set_state(RewriteProfile.name)
    await event.message.answer(f"Ваше текущее имя: {user_profile.name}. Введите новое имя:")

@router.message(Command('cancel'))
async def cancel_reg(event: Message | CallbackQuery, state: FSMContext):
    await state.clear()

    await callback_menu(event)

@router.message(RewriteProfile.name)
async def state_edit_name(message: Message, state: FSMContext):
    """Редактирование имени пользователя."""
    await state.update_data(name=message.text)
    await message.answer("Сколько вам лет?")
    await state.set_state(RewriteProfile.age)


@router.message(RewriteProfile.age)
async def state_edit_age(message: Message, state: FSMContext):
    """Редактирование возраста."""
    await state.update_data(age=int(message.text))
    await message.answer("Определимся с полом?", reply_markup=user_sex)
    await state.set_state(RewriteProfile.isMale)


@router.message(RewriteProfile.isMale)
async def state_edit_gender(message: Message, state: FSMContext):
    """Редактирование пола."""
    if message.text == "Мужской":
        isMale = True
    elif message.text == "Женский":
        isMale = False
    else:
        await message.answer("Пожалуйста, выберите пол из предложенных вариантов: Мужской или Женский.")
        return  # Прекращаем выполнение при некорректном вводе

    await state.update_data(isMale=isMale)
    await message.answer("Введите вашу программу:", reply_markup=ReplyKeyboardRemove())
    await state.set_state(RewriteProfile.faculty)


@router.message(RewriteProfile.faculty)
async def state_edit_faculty(message: Message, state: FSMContext):
    """Редактирование факультета."""
    await state.update_data(faculty=message.text)

    await message.answer('На каком ты уровне образования?', reply_markup=user_isBaccalaureate)
    await state.set_state(RewriteProfile.isBaccalaureate)


@router.message(RewriteProfile.isBaccalaureate)
async def state_edit_degree(message: Message, state: FSMContext):
    
    if message.text == 'Бакалавриат':
        await state.update_data(is_bac=True)
    elif message.text == 'Магистратруа':
        await state.update_data(is_bac=False)
    await message.answer("На каком вы курсе?", reply_markup=user_course_bac)
    await state.set_state(RewriteProfile.course)



@router.message(RewriteProfile.course)
async def state_edit_course(message: Message, state: FSMContext):
    """Редактирование курса."""
    await state.update_data(course=int(message.text))
    await message.answer("Отправь свое фото", reply_markup=no_photo)
    await state.set_state(RewriteProfile.photo)


@router.message(RewriteProfile.photo, lambda message: message.photo or message.text)
async def user_photo_inf(message: Message, state: FSMContext):
    if message.text == "Без фото":
        await state.update_data(photo=None)
        await state.set_state(RewriteProfile.about)
    else:
        bot = message.bot  # Получаем объект бота

        # Создаем директорию, если она не существует
        downloads_dir = f'account_photos/{message.chat.id}'
        if not os.path.exists(downloads_dir):
            os.makedirs(downloads_dir)

        try:
            # Получаем наибольший размер фото
            photo = message.photo[-1]
            file_id = photo.file_id  # Получаем file_id

            # Загружаем файл по file_id
            file = await bot.get_file(file_id)

            # Сохраняем файл в нужную директорию
            destination = f"{downloads_dir}/{file_id}.jpg"
            await bot.download_file(file.file_path, destination)

            await message.answer("Фото успешно загружено!")
            await state.update_data(photo=destination)  # Сохраняем путь в состояние
        except Exception as e:
            await message.answer(f"Ошибка при загрузке фото: {e}")

    await message.answer("Расскажи о себе", reply_markup=no_about)
    await state.set_state(RewriteProfile.about)


@router.message(RewriteProfile.about)
async def user_about_inf(message: Message, state: FSMContext):
    if message.text == "Без текста":
        await state.update_data(about='None')
    else:
        await state.update_data(about=message.text)

    await message.answer('Кого ты хочешь найти?', reply_markup=user_friend_sex)
    await state.set_state(RewriteProfile.friend_sex)


@router.message(RewriteProfile.friend_sex)
async def user_friend_sex_inf(message: Message, state: FSMContext):
    if message.text == "Мужчины":
        await state.update_data(friends_sex="males")
    elif message.text == "Девушки":
        await state.update_data(friends_sex="females")
    elif message.text == "Без разницы":
        await state.update_data(friends_sex="dont_care")
    
    # Получение обновленных данных и сохранение в базу данных
    data = await state.get_data()
    async with accounts_db_session() as session:
        async with session.begin():
            query = select(AccountsTable).where(AccountsTable.chat_id == data['profile'].chat_id)
            result = await session.execute(query)
            user_profile = result.scalar_one()

            # Обновление данных профиля
            user_profile.name = data['name']
            user_profile.age = data['age']
            user_profile.isMale = data['isMale']
            user_profile.faculty = data['faculty']
            user_profile.isBaccalaureate = data['is_bac']
            user_profile.course = data['course']
            user_profile.photo = data['photo']
            user_profile.about = data['about']
            user_profile.friend_sex = data['friends_sex']

            await session.commit()

    await message.answer("Профиль успешно обновлен!", reply_markup=back_to_main)
    await state.clear()
    
