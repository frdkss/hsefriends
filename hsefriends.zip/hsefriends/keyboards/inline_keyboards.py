from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton

first_registration_keyboard = InlineKeyboardMarkup(row_width=1,
                                                   inline_keyboard=[
                                                       [InlineKeyboardButton(text='Начать регистрацию', callback_data='first_reg')],
                                                       [
                                                           InlineKeyboardButton(text='Пользовательское Соглашение', url='https://telegra.ph/Polzovatelskoe-Soglashenie-10-15-13'),
                                                           InlineKeyboardButton(text='Политика Конфиденциальности', url='https://telegra.ph/Politika-Konfidencialnosti-10-15-12')
                                                       ]
                                                   ])

main_menu = InlineKeyboardMarkup(row_width=2,
                                 inline_keyboard=[
                                     [
                                         InlineKeyboardButton(text='Искать друзей!', callback_data='start_search'),
                                         InlineKeyboardButton(text='Мой профиль', callback_data='profile'),
                                     ],
                                     [
                                         InlineKeyboardButton(text='Настройки', callback_data='settings')
                                     ]#,
                                     # [
                                     #     InlineKeyboardButton(text='Помощь', callback_data='help')
                                     # ]
                                 ])

# main_settings = InlineKeyboardMarkup(row_width=3,
#                                      inline_keyboard=[
#                                          [
#                                              InlineKeyboardButton(text='Изменить профиль', callback_data='edit_profile'),
#                                              InlineKeyboardButton(text='Перезаписать профиль',
#                                                                   callback_data='rewrite_profile'),
#                                              InlineKeyboardButton(text='Удалить профиль', callback_data='delete_profile')
#                                          ],
#                                          [
#                                              InlineKeyboardButton(text='Обратная связь', callback_data='feedback')
#                                          ],
#                                          [
#                                              InlineKeyboardButton(text="В меню", callback_data="menu")
#                                          ]
#                                      ])

main_settings = InlineKeyboardMarkup(row_width=2,
                                     inline_keyboard=[
                                         [
                                             InlineKeyboardButton(text='Перезаписать профиль',
                                                                  callback_data='rewrite_profile'),
                                             InlineKeyboardButton(text='Удалить профиль', callback_data='delete_profile')
                                         ],
                                         [
                                             InlineKeyboardButton(text='Обратная связь', callback_data='feedback')
                                         ],
                                         [
                                             InlineKeyboardButton(text="В меню", callback_data="menu")
                                         ]
                                     ])

feedback_url = InlineKeyboardMarkup(row_width=1,
                                    inline_keyboard=[
                                        [
                                            InlineKeyboardButton(text="Связаться с разработчиком", url="https://t.me/qqqqqqqqqpqpws", callback_data="feedback_account")
                                        ],
                                        [
                                            InlineKeyboardButton(text="В меню", callback_data="menu")
                                        ]
                                    ])

edit_profile = InlineKeyboardMarkup(row_width=3,
                                    inline_keyboard=[
                                        [
                                            InlineKeyboardButton(text='Имя', callback_data='edit_name'),
                                            InlineKeyboardButton(text='Возраст', callback_data='edit_age'),
                                            InlineKeyboardButton(text='Пол', callback_data='edit_sex')
                                        ],
                                        [
                                            InlineKeyboardButton(text='Факультет', callback_data='edit_faculty'),
                                            InlineKeyboardButton(text='Степень', callback_data='edit_degree'),
                                            InlineKeyboardButton(text='Курс', callback_data='edit_course')
                                        ],
                                        [
                                            InlineKeyboardButton(text='Фото', callback_data='edit_photo'),
                                            InlineKeyboardButton(text='"О себе"', callback_data='edit_about'),
                                            InlineKeyboardButton(text='Пол друга', callback_data='edit_friend_sex')
                                        ],
                                        [
                                            InlineKeyboardButton(text="В меню", callback_data="menu")
                                        ]
                                    ])
assessment_menu = InlineKeyboardMarkup(row_width=2,
                                       inline_keyboard=[
                                           [
                                               InlineKeyboardButton(text='👍', callback_data='like'),
                                               InlineKeyboardButton(text='👎', callback_data='dislike'),
                                           ],
                                           [
                                               InlineKeyboardButton(text='В меню', callback_data='menu')
                                           ]
                                       ])

research = InlineKeyboardMarkup(row_width=2,
                                inline_keyboard=[
                                    [
                                        InlineKeyboardButton(text='Перезапустить поиск', callback_data="restart_search")
                                        # InlineKeyboardButton(text='Обновить анкеты', callback_data='update_search')
                                    ],
                                    [
                                        InlineKeyboardButton(text="В меню", callback_data="menu")
                                    ]
                                ])

back_to_main = InlineKeyboardMarkup(row_width=1,
                                    inline_keyboard=[
                                        [
                                            InlineKeyboardButton(text="В меню", callback_data="menu")
                                        ]
                                    ])
                                    
next_anketa = InlineKeyboardMarkup(row_width=1,
                                    inline_keyboard=[
                                        [
                                            InlineKeyboardButton(text="Продолжить поиск", callback_data="start_search")
                                        ]
                                    ])
